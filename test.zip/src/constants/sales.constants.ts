export default {
  PAGINATION_ITEMS_PER_PAGE: 10,
};
